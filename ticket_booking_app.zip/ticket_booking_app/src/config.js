export const config = {
    api : 'https://hackathonbackendbookticket.herokuapp.com'
}